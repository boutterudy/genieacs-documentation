# backward compatibility for chkbuild
require_relative '../basictest/test'
