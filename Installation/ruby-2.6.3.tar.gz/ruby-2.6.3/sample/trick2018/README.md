This directory contains the award-winning entries of
the 3rd Transcendental Ruby Imbroglio Contest for rubyKaigi (TRICK 2018).

THESE ARE BAD EXAMPLES!  You must NOT use them as a sample code.

* 01-kinaba/entry.rb: "Most reserved" - **Gold award**
* 02-mame/entry.rb: "Best spiral" - **Silver award**
* 03-tompng/entry.rb: "Best png viewer" - **Bronze award**
* 04-colin/entry.rb: "Best one-liner" - 4th prize
* 05-tompng/entry.rb: "Most three-dimensional" - 5th prize

These files are licensed under MIT license.

For the contest outline and other winning entries, see:

https://github.com/tric/trick2018
