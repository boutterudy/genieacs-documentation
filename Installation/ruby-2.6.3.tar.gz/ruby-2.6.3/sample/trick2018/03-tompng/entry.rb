X=[];class String def-@;replace ?-+self end;def-a;X.reject!{|x|x.
__id__==__id__};a.replace(self+?-+a) end end;at_exit{eval C=(Zlib
.inflate((X*?-).tr(?-,'').tr('q-z','0-9').to_i(26).digits(0x100).
pack'C*'))};def method_missing n;(X<<n.to_s)[-1]end;require'zlib'
fzygtoxyzgntmdmuwvfoffbpmvzojpkhczvjvjdbtscnldwbdoprackddovivvmkz
ponzmosvtjciwkgaslscxxxwudeesmmqpfhislxuxnnypulxstzgobyaekqqhbjcg
mvko------------ddkeys----eivhnccaqyiw---bzyccmt-----------ymtnge
jwhi--------------pjxf------mdarbtumnv---qasda--------------gmwdt
wrtk---qtpzgnce----fsl-------fkgzgtbpp---gwnm----pxkpqkdiw---owga
momz---yjjvpnvar---zeo---v-----duvalwu---nsqt---waofemwakivnyqkjd
fzag---uhvusmkl----kzb---rhc----iutzjr---mqlh---ayijpwativpweaato
xexs--------------rvgv---pjdz-----lkkg---uiaw---lovitupw-----fwmn
kfru------------jvjpgv---jskycf----pal---gbuf---hfdnywog-----iuca
pntn---apmkqroeuzwuwkw---gqnmgof-----b---hlpl---vkkyhfyrqfr--jwrl
kmdb---dhspujhmtgrkccu---uonfummdt-------rqfw----bpiactehwp--fncq
yzvz---gdaxebplhfndran---ytfmviryeh------hqwkl---------------nced
bibu---fnkdthgldhkxxjg---rwnmpudhbqin----gucoyki------------hfura
cqdgqpyzqfzknvdjoxxhpjulwwyebtocxdrvklbuviwwcatlmdosxfvwntzbijguy
iglrvvzlxerflupxvsyujfacuwhrvmnecgtewtqkhtdggcltejiyqcluclkycwvzg
vvxfysvttfbeglvrlngntdngzyhqrmltazwdydxrsvjploembhgxdvfmmhepbschm
brn--iqrcdb--evv----tqp------lg--uein-wzut--mr------wkh------foqz
zsf--srjnjp--ampb--pfio--hgtekx--rrr---fwd--jn--xqkezcz--vsb--nya
khrc--evlr--oioxs--mqce--bqfmag--bwz---xda--qw--jnuzelr--qzi--itx
mdxd--duso--wxbot--nmon--ugnbdpc--a--c--e--hlg--twxndre--tby--rhg
evhbn--zb--dtxmiz--dpia------vie--h--i--t--shh------kfn------owna
ealmt--kb--scxdjy--smvl--dqmgebk--t--s--t--gfd--updcbnc--rh--dwwp
dvpnxb----wpljjdy--kolc--qflyleok---xkv---usbj--jhrawbn--ewx--bgf
eaqwrw----ejwxhet--dice--eoczconm---urz---rqyp--hovvvfc--bskj--el
aocjcts--jtumwxm----mgy------xpaoq-jtwqr-aipay------dhy--iync--hk
sckddmvuvvuhhqstumaykvczaaujrumqbbqsdvdycplyrlkkojlxnkrhbbrmnjxyf
cdtcmpfmjvthwkpzucbblttgumomlxnxwjeypfeagaukfzeokzxjebkpigcvlqnso
