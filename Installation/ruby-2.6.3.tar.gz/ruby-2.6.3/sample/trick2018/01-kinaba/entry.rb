alias    BEGIN    for      unless   def      class
super    true     or       return   defined? next
break    while    begin    undef    do       end
rescue   then     retry    else     undef    module
nil      ensure   case     if       yield    __LINE__
self     and      redo     elsif    not      __FILE__
alias    END      in       end      when     __ENCODING__
end      until    false    end
