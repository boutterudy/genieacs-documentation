'';eval(r=%q(->z{r="'';eval(r=\
%q(#{r}))[%q`#{z}`]";i=-040;30.
times{|n|(15+n%2*15-n/2).times{
r<<r[i+=(1.-n&2)*(32-n%2*31)]}}
i=r[524,0]=?\0;eval(r[479..-1])
c['"']}))[%q`GFEDCBA"+"[e\"'"'t
kE*;;\";"  TRICK2018  ";tb,;{{r
2E0$ob[us@*0)[90,336])_#i\n}s#i
0H}>["t]];};o[1,?\n*8];ex"-}eac
1Hl<1[-1]*2*t=n%2];o[14-n,0)mvk
8M$<4,?\n];15.times{|n|;o[35ie2
!Pss.slice!(0,1)+x;sleep(0.0t;0
'W=%q"<<95<<$s<<95;o=->n,x{n.'1
;@[2]}|\e../,%@s="'%trick2018!8
eval$s=%q_eval($s.gsub!(/#{%@`]
