'use strict';
require('../common');
process.stdin.end('foobar\n');
